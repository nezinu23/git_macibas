# Ķīmijas laboratorijas uzskaites — 3 formas (statisks projekts)
Šis nelielais statiskais tīmekļa projekts satur trīs lapas (formas) un pārejas starp tām, kā prasīts uzdevumā.
Izmantots parauga PDF: PD_Formas.pdf. fileciteturn0file0

## Ko satur
- `index.html` — 1. forma (sākuma lapa). No tās var pāriet uz 2. un 3. formu.
- `form2.html` — 2. forma (Login/Register). Ja lauki `username` un `password` nav tukši, var turpināt uz 3. formu.
- `form3.html` — 3. forma (detaļu ievade). No tās var atgriezties uz 1. formu.
- `styles.css` — stils/formas noformējums.
- `script.js` — vienkārša JS loģika 2. formai (pārbauda, vai kaut kas ierakstīts).

## Kā palaist (Replit vai lokāli)
1. Izveido jaunu Replit statisku tīmekļa (HTML, CSS, JS) projektu un augšupielādē šos failus vai
2. Lokāli: atver `index.html` pārlūkā vai izmanto vienkāršu serveri: `python -m http.server` projekta mapē.

## Piezīmes
- Formas nav funkcionālas (nav servera-side glabāšanas). Uzdevumā bija prasīts tikai izskats un pārejas starp lapām.
- 2. formā ir vienkārša pārbaude, kas prasa, lai lauki nebūtu tukši — tikai, lai varētu turpināt uz 3. formu.
