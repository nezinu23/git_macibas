// Simple client-side logic: require non-empty username and password to proceed to form3.
document.addEventListener('DOMContentLoaded', function(){
  var loginBtn = document.getElementById('loginBtn');
  var registerBtn = document.getElementById('registerBtn');
  var error = document.getElementById('error');

  function checkAndGo(){
    var u = document.getElementById('username').value.trim();
    var p = document.getElementById('password').value.trim();
    if(!u || !p){
      error.textContent = 'Lūdzu ievadi vārdu un paroli, lai turpinātu.';
      return;
    }
    // If something is typed, continue to form3 (no saving).
    window.location.href = 'form3.html';
  }

  if(loginBtn) loginBtn.addEventListener('click', checkAndGo);
  if(registerBtn) registerBtn.addEventListener('click', checkAndGo);
});
